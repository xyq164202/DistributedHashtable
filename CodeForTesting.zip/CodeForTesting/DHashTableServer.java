import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class DHashTableServer {
    private int port;
    private Map<String, String> data = new Hashtable<String, String>();
    private ServerSocket serverSocket;
    private List<Socket> clients = new ArrayList<Socket>();

    public DHashTableServer(int port) {
        this.port = port;
    }
    public boolean put(String key, String value) {
        if(key == null || value == null) {
            return false;
        }
        if(data.put(key, value) == null) {
            return false;
        }
        //System.out.println("put successfully");
        return true;
    }
    public String get(String key) {
        //System.out.println("get successfully");
        return data.get(key);
    }
    public boolean del(String key) {
        if(key == null) {
            return false;
        }
        if(data.remove(key) == null) {
            return false;
        }
        //System.out.println("del successfully");
        return true;
    }

    /*
    public void start() {
        try {
            serverSocket = new ServerSocket(port);
            while(true) {
                System.out.println("accept.." + port);
                Socket socket = serverSocket.accept();
                //System.out.println("A client connected...");
                clients.add(socket);
                //new ReadSocket(socket, data).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    */
    public static void main(String[] args) throws Exception{
        for(int i = 0; i < 8; ++i) {
            int port = 8000 + i;
            DHashTableServer server = new DHashTableServer(port);
            new Doit(server, port, server.data).start();

            /*
            System.out.println("port: " + port);
            ServerSocket serverSocket = new ServerSocket(port);
            */
        }
        while(true) {
            Thread.sleep(10000);
        }
    }
}

class Doit extends Thread{
    private DHashTableServer server;
    private List<Socket> clients;
    private int port;
    private Map<String, String> data;

    public Doit(DHashTableServer server, int port, Map<String, String> data) {
        this.server = server;
        this.port = port;
        this.data = data;
    }

    @Override
    public void run() {
        Socket socket = null;
        try {
            //System.out.println("server port: " + port);
            ServerSocket serverSocket = new ServerSocket(port);
            while(true) {
                System.out.println("port " + port + " accept..");
                socket = serverSocket.accept();
                System.out.println("A client connected to ..." + port);
                //clients.add(socket);
                //new ReadSocket(socket, data).start();
                InputStream inputStream = socket.getInputStream();
                OutputStream outputStream = socket.getOutputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
                String line;
                while((line = reader.readLine()) != null) {
                    String[] splits = line.split(" ");
                    String order = splits[0];
                    String key = splits[1];
                    String value = null;
                    if (order.equals("put")) {
                        value = splits[2];
                        if(value.equals("end")) {
                            System.out.println("continus test is over");
                            writer.write("end\r\n");
                            writer.flush();
                            break;
                        }
                        data.put(key, value);
                        writer.write("1\r\n");
                        writer.flush();
                    } else if (order.equals("get")) {
                        value = data.get(key);
                        if (value == null) {
                            writer.write("0\r\n");
                        } else {
                            writer.write(value + "\r\n");
                        }
                        writer.flush();
                    } else if (order.equals("del")) {
                        value = data.remove(key);
                        if (value == null) {
                            writer.write("0\r\n");
                        } else {
                            writer.write(value + "\r\n");
                        }
                        writer.flush();
                    }
                    else if(order.equals("end")) {
                        System.out.println("contiunus test is over");
                        break;
                    }
                    else {
                        System.out.println("Wrong request from client");
                    }
                }
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                socket.close();
            } catch (Exception e) {

            }
        }
    }
}

/*
class ReadSocket extends Thread {
    private Socket socket;
    private Map<String, String> data;

    public ReadSocket(Socket socket, Map<String, String> data) {
        this.socket = socket;
        this.data = data;
    }
    @Override
    public void run() {
        try {
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            String line;
            if((line = reader.readLine()) != null) {
                String[] splits = line.split(" ");
                String order = splits[0];
                String key = splits[1];
                String value = null;
                if(order.equals("put")) {
                    value = splits[2];
                    data.put(key, value);
                    writer.write("1\r\n");
                    writer.flush();
                }
                else if(order.equals("get")) {
                    value = data.get(key);
                    if(value == null) {
                        writer.write("0\r\n");
                    }
                    else  {
                        writer.write(value + "\r\n");
                    }
                    writer.flush();
                }
                else if(order.equals("del")) {
                    value = data.remove(key);
                    if(value == null) {
                        writer.write("0\r\n");
                    }
                    else  {
                        writer.write(value + "\r\n");
                    }
                    writer.flush();
                }
                else {
                    System.out.println("Wrong request from client");
                }
                socket.close();
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                socket.close();
            } catch (Exception e) {
            }
        }
    }
}
*/
