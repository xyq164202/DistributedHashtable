import java.io.*;
import java.net.Socket;
import java.util.*;

public class DHashTableClient {
    private BufferedReader reader;
    private BufferedWriter writer;
    private List<Integer> serverCount = new ArrayList<Integer>();
    private Map<Integer, Socket> sockets = new HashMap<>();


    public DHashTableClient() {
        for(int i = 0; i < 8; ++i) {
            serverCount.add(0);
        }
    }

    public void tryConnect(int port, Socket socket) {
        try {
            socket = new Socket("127.0.0.1", port);
        } catch (Exception e) {
            return;
        }
    }

    public Socket connect(int port) {
        Socket socket = null;
        try {
            //System.out.println("connect to " + port);
            socket = sockets.get(port);
            if(socket == null) {
                socket = new Socket("127.0.0.1", port);
                sockets.put(port, socket);
            }
            /*
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            */
            return socket;
        } catch (Exception e) {
            //e.printStackTrace();
            //tryConnect(port, socket);
            return connect(port);
        }
    }
    public boolean put(String key, String value) {
        if(key == null) {
            return false;
        }
        String res = null;
        Socket socket = null;
        try {
            int port = 8000 + key.hashCode() % 8;
            if(port < 8000 || port > 8007) {
                System.out.println("port wrong, port = " + port + ", key = " + key);
                return false;
            }
            socket = connect(port);
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();
            BufferedReader reader1 = new BufferedReader(new InputStreamReader(inputStream));
            BufferedWriter writer1 = new BufferedWriter(new OutputStreamWriter(outputStream));
            writer1.write("put " + key + " " + value + "\r\n");
            writer1.flush();
            res = reader1.readLine();
            int index = port - 8000;
            int oldCount = serverCount.get(index);
            serverCount.set(index, oldCount + 1);
            //socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                //socket.close();
            } catch (Exception e) {

            }
        }
        if(res.equals("1")) {
            return true;
        }
        else {
            return false;
        }
    }
    public String get(String key) {
        if(key == null) {
            return null;
        }
        String res = null;
        try {
            int port = 8000 + key.hashCode() % 8;
            Socket socket = connect(port);
            writer.write("get " + key + "\r\n");
            writer.flush();
            res = reader.readLine();
            int index = port - 8000;
            int oldCount = serverCount.get(index);
            serverCount.set(index, oldCount + 1);
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(res.equals("0")) {
            return null;
        }
        else {
            return res;
        }
    }
    public String del(String key) {
        if(key == null) {
            return null;
        }
        String res = null;
        try {
            int port = 8000 + key.hashCode() % 8;
            Socket socket = connect(port);
            writer.write("del " + key + "\r\n");
            writer.flush();
            res = reader.readLine();
            int index = port - 8000;
            int oldCount = serverCount.get(index);
            serverCount.set(index, oldCount + 1);
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(res.equals("0")) {
            return  null;
        }
        else {
            return res;
        }
    }
    public void printCount() {
        System.out.println("Count of different servers: ");
        for(int i = 0; i < 8; ++i) {
            System.out.print(serverCount.get(i) + " ");
        }
        System.out.println();
    }
    public static void main(String[] args) throws Exception{
        DHashTableClient client = new DHashTableClient();
        System.out.println("Begin: " + new Date());
        for(int i = 100000; i < 199999; ++i) {
            String key = String.valueOf(i);
            client.put(key, "hello");
            if(i % 10000 == 0) {
                //System.out.println("finish 10000");
                //System.out.println(new Date());
            }
        }
        client.put("end", "end");
        System.out.println("End: " + new Date());
        client.printCount();
        /*
        while(true) {
            Thread.sleep(10000);
        }
        */
    }
}
